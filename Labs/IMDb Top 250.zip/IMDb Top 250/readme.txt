Which decade had the greatest (highest) number of movies?
في أي عقد كان أكبر (أعلى) عدد من الأفلام؟

https://www.imdb.com/chart/top